
// 5 seconds timer
setTimeout(function() {
    // Hide the GIF after
    document.getElementById("gif-container").style.display = "none";
    
    // Body
    document.getElementById("main-content").style.display = "block";
}, 5000); // 5000 milliseconds = 5 seconds


function scrollToAboutMe() {
    // Scroll to the About Me section
    document.getElementById('Home').scrollIntoView({ behavior: 'smooth' });
}

function scrollToAboutMe() {
    // Scroll to the About Me section
    document.getElementById('AboutMe').scrollIntoView({ behavior: 'smooth' });
}

function scrollToAboutMe() {
    // Scroll to the About Me section
    document.getElementById('Projects').scrollIntoView({ behavior: 'smooth' });
}

function scrollToAboutMe() {
    // Scroll to the About Me section
    document.getElementById('Contacts').scrollIntoView({ behavior: 'smooth' });
}